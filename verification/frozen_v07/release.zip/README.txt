星织 Asterweave —— 单文件 H5 游戏
解压后直接双击 index.html 即可离线游玩（无需联网、无外部依赖）。
也可直接把 index.html 拖进浏览器。
